import setup from "./setup";

export { BLOCK_SIZE } from "./aes";
export default setup;
