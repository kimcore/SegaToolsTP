export interface LoadGeneralRewardResponse2 {
  type: "load_general_reward_res";
  format: 2;
  // TBD
}
