export interface LoadConfigResponse2 {
  type: "load_config_v2_res";
  status: number;
}
