export interface SaveTopicResponse {
  type: "save_topic_res";
  // mega TODO
}
