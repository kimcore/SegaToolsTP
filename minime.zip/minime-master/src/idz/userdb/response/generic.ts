export interface GenericResponse {
  type: "generic_res";
  status?: number;
  // a bunch of other stuff here! total size is 0x20
}
