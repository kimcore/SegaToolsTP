import { BaseTeamResponse } from "./_team";

export interface LoadTeamResponse extends BaseTeamResponse {
  type: "load_team_res";
}
