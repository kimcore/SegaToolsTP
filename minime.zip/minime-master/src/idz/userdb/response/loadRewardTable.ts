export interface LoadRewardTableResponse {
  type: "load_reward_table_res";
  // TODO
}
