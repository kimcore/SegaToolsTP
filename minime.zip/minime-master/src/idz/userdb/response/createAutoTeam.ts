import { BaseTeamResponse } from "./_team";

export interface CreateAutoTeamResponse extends BaseTeamResponse {
  type: "create_auto_team_res";
}
