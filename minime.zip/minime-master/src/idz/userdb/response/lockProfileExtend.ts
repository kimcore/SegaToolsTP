export interface LockProfileExtendResponse {
  type: "lock_profile_extend_res";
  status: number;
}
