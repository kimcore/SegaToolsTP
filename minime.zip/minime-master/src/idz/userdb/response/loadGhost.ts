export interface LoadGhostResponse {
  type: "load_ghost_res";
}
