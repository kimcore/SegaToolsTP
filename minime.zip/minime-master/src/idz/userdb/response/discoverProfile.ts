export interface DiscoverProfileResponse {
  type: "discover_profile_res";
  exists: boolean;
}
