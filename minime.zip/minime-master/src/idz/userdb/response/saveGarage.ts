export interface SaveGarageResponse {
  type: "save_garage_res";
  status: number;
}
