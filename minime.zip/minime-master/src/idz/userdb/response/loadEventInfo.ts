export interface LoadEventInfoResponse {
  type: "load_event_info_res";
}
