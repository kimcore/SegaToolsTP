export interface SaveTimeAttackResponse {
  type: "save_time_attack_res";
}
