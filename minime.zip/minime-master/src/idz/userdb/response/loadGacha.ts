export interface LoadGachaResponse {
  type: "load_gacha_res";
  awardedToday: boolean;
}
