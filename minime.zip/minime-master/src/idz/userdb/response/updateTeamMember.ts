export interface UpdateTeamMemberResponse {
  type: "update_team_member_res";
  status: number;
}
