export interface LoadConfigResponse {
  type: "load_config_res";
  status: number;
  serverVersion: number;
}
