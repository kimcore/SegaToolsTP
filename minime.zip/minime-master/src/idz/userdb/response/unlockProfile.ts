export interface UnlockProfileResponse {
  type: "unlock_profile_res";
  status: number;
}
