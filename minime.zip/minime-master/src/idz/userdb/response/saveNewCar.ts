export interface SaveNewCarResponse {
  type: "save_new_car_res";
  status: number;
}
