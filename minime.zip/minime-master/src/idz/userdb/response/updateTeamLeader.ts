export interface UpdateTeamLeaderResponse {
  type: "update_team_leader_res";
  status: number;
}
