export interface LoadTeamRankingResponse {
  type: "load_team_ranking_res";
  // TODO
}
