export interface Settings {
  music: number;
  pack: number;
  aura: number;
  paperCup: number;
  gauges: number;
}
