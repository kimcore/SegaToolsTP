export interface UpdateUserLogRequest {
  type: "update_user_log_req";
}
