export interface LoadConfigRequest2 {
  type: "load_config_v2_req";
}
