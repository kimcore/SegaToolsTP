export interface CheckTeamNameRequest {
  type: "check_team_name_req";
}
