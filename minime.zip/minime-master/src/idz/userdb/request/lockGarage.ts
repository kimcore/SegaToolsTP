export interface LockGarageRequest {
  type: "lock_garage_request";
  field_0004: number;
}
