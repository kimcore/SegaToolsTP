export interface SaveTopicRequest {
  type: "save_topic_req";
  aimeId?: number;
}
