export interface LoadServerListRequest {
  type: "load_server_list_req";
}
