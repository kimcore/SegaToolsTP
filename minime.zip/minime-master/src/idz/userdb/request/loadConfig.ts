export interface LoadConfigRequest {
  type: "load_config_req";
}
