export interface UpdateProvisionalStoreRankRequest {
  type: "update_provisional_store_rank_req";
  aimeId: number;
}
