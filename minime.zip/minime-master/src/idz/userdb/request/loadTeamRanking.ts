export interface LoadTeamRankingRequest {
  type: "load_team_ranking_req";
}
