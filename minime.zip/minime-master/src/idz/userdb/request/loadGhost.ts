export interface LoadGhostRequest {
  type: "load_ghost_req";
  field_0002: number; // u16
  field_0004: number; // u16
  field_0008: number; // u32
  field_000C: number; // u16
  field_000E: number; // u16
}
