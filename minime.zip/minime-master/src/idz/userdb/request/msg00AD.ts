export interface Message00AD {
  type: "msg_00AD_req";
}
