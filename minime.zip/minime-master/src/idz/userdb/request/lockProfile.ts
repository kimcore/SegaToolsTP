export interface LockProfileRequest {
  type: "lock_profile_req";
  aimeId: number;
  pcbId: string;
  field_0018: number;
}
