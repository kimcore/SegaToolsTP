export interface UpdateTeamPointsRequest {
  type: "update_team_points_req";
  field_0004: number;
  field_0008: number;
}
