export interface UpdateResultRequest {
  type: "update_result_req";
  field_0002: number;
  field_0004: number;
  field_0008: number;
  field_000C: number;
  field_0010: number;
  field_0014: number;
  field_0016: number;
  field_0018: number;
  field_0019: number;
  field_001A: number;
  field_001C: number;
  field_0020: number;
  field_0024: number;
}
