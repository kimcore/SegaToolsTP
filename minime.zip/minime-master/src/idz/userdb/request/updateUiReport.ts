export interface UpdateUiReportRequest {
  type: "update_ui_report_req";
  field_02: number;
  field_04: number;
}
