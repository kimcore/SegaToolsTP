export interface UnlockProfileRequest {
  type: "unlock_profile_req";
  aimeId: number;
  pcbId: string;
}
