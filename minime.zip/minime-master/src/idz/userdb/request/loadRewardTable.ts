export interface LoadRewardTableRequest {
  type: "load_reward_table_req";
}
