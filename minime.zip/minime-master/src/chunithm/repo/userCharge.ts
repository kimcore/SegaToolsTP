import { UserChargeItem } from "../model/userCharge";
import { RepositoryN } from "./_defs";

export type UserChargeRepository = RepositoryN<UserChargeItem>;
