import { RepositoryN } from "./_defs";
import { UserMusicDetailItem } from "../model/userMusic";

export type UserMusicRepository = RepositoryN<UserMusicDetailItem>;
