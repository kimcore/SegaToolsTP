import { Repository1 } from "./_defs";
import { UserGameOptionExItem } from "../model/userGameOptionEx";

export type UserGameOptionExRepository = Repository1<UserGameOptionExItem>;
