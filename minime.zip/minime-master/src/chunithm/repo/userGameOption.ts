import { Repository1 } from "./_defs";
import { UserGameOptionItem } from "../model/userGameOption";

export type UserGameOptionRepository = Repository1<UserGameOptionItem>;
