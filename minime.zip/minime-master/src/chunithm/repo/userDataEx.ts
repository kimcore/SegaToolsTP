import { Repository1 } from "./_defs";
import { UserDataExItem } from "../model/userDataEx";

export type UserDataExRepository = Repository1<UserDataExItem>;
