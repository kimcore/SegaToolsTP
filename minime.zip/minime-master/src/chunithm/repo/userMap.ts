import { RepositoryN } from "./_defs";
import { UserMapItem } from "../model/userMap";

export type UserMapRepository = RepositoryN<UserMapItem>;
