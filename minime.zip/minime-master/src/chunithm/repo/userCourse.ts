import { UserCourseItem } from "../model/userCourse";
import { RepositoryN } from "./_defs";

export type UserCourseRepository = RepositoryN<UserCourseItem>;
