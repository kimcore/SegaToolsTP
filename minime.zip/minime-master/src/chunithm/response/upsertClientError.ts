export interface UpsertClientErrorResponse {
  /** Integer */
  returnCode: string;
}
