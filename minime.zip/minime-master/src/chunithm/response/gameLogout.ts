export interface GameLogoutResponse {
  /** Integer */
  returnCode: string;
}
