export interface UpsertClientTestmodeResponse {
  /** Integer */
  returnCode: string;
}
