export interface GameLoginResponse {
  /** Integer */
  returnCode: string;
}
