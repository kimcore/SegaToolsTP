export interface UpsertUserChargelogApiResponse {
    returnCode: string;
}