export interface UpsertUserAllResponse {
  /** Integer */
  returnCode: string;
}
