export interface UpsertClientBookkeepingResponse {
  returnCode: string;
}
