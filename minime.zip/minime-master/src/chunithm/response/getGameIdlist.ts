export interface GetGameIdlistResponse {
  /** Integer */
  type: string;

  /** Integer */
  length: string;

  /** Format TBD */
  gameIdlistList: [];
}
