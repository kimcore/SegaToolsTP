export interface UpsertClientSettingResponse {
  /** Integer */
  returnCode: string;
}
