export interface UpsertClientDevelopResponse {
  /** Integer */
  returnCode: string;
}
