export const CHARGE_IDS = Object.freeze([
  {
    id: 2310, //World's End ticket x5
    price: 1,
    salePrice: 1,
  },
  {
    id: 2060, //4x bonus ticket
    price: 1,
    salePrice: 1,
  },
  {
    id: 2230, //6 songs premium ticket
    price: 2,
    salePrice: 2,
  },
]);