export interface GetUserMapRequest {
  /** Integer, AiMe ID */
  userId: string;

  /** Boolean */
  isAllMap: string;
}
