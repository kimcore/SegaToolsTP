export interface GetUserDataRequest {
  /** Integer, AiMe ID */
  userId: string;
}
