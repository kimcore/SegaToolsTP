export interface UpsertClientErrorRequest {
  // FIXME
}
