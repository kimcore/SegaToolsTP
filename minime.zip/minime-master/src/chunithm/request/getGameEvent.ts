export interface GetGameEventRequest {
  // FIXME
  type: string;
}
