export interface GetUserOptionRequest {
  /** Integer, AiMe ID */
  userId: string;
}
