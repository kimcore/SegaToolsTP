export interface GetUserRegionRequest {
  // FIXME

  /** Integer, AiMe ID */
  userId: string;
}
