export interface GetGameSettingRequest {
  /** Base-10 ALLNet location ID */
  placeId: string;

  /** Keychip ID */
  clientId: string;
}
