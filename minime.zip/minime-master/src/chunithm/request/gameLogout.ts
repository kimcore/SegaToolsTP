export interface GameLogoutRequest {
  /** Integer, AiMe ID */
  userId: string;
}
