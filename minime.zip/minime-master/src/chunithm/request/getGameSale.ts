export interface GetGameSaleRequest {
  /** Integer */
  type: string;

  /** Boolean */
  isAllSale: string;
}
