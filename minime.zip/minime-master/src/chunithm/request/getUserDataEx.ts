export interface GetUserDataExRequest {
  /** Integer, AiMe ID */
  userId: string;

  /** Boolean */
  isAdmin: string;
}
