export interface GameLoginRequest {
  /** Integer, AiMe ID */
  userId: string;
}
