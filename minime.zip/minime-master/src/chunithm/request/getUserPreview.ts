export interface GetUserPreviewRequest {
  /** Integer, AiMe ID */
  userId: string;

  segaIdAuthKey: string;
}
