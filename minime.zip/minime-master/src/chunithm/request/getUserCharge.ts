export interface GetUserChargeRequest {
  /** Integer, AiMe ID */
  userId: string;
}
