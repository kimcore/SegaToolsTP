export interface GetGameIdlistRequest {
  /** Integer */
  type: string;
}
