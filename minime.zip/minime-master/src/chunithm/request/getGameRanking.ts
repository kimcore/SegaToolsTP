export interface GetGameRankingRequest {
  /** Long */
  type: string;
}
