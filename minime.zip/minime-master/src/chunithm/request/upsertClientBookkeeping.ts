export interface UpsertClientBookkeepingRequest {
  // FIXME
}
