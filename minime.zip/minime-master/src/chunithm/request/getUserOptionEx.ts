export interface GetUserOptionExRequest {
  /** Integer, AiMe ID */
  userId: string;

  /** Boolean */
  isAdmin: string;
}
