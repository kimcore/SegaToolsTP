export interface GetUserRecentRatingRequest {
  /** Integer, AiMe ID */
  userId: string;
}
