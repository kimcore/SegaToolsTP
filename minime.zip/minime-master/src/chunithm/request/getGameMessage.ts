export interface GetGameMessageRequest {
  /** Integer */
  type: string;

  /** Boolean */
  isAllMessage: string;
}
