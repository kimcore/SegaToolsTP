export interface GetUserDuelRequest {
  /** Integer, AiMe ID */
  userId: string;

  /** Integer */
  duelId: string;

  /** Boolean */
  isAllDuel: string;
}
