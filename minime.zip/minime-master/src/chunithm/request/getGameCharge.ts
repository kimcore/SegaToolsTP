export interface GetGameChargeRequest {
  /** Boolean */
  isAllSale: "string";
}
