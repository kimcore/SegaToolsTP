export interface UserChargeItem {
  chargeId: number;
  stock: number;
  purchaseDate: Date;
  validDate: Date;
  param1: number;
  param2: number;
  paramDate: Date;
}
