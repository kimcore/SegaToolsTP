export interface UserGameOptionExItem {
  ext1: number;
  ext2: number;
  ext3: number;
  ext4: number;
  ext5: number;
  ext6: number;
  ext7: number;
  ext8: number;
  ext9: number;
  ext10: number;
  ext11: number;
  ext12: number;
  ext13: number;
  ext14: number;
  ext15: number;
  ext16: number;
  ext17: number;
  ext18: number;
  ext19: number;
  ext20: number;
}
