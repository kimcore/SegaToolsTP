export interface GameEventItem {
  type: number;
  id: number;
  startDate: Date;
  endDate: Date;
}
