export interface GameMessageItem {
  type: number;
  id: number;
  message: string;
  startDate: Date;
  endDate: Date;
}
