export interface UserRecentRatingItem {
  musicId: number;
  difficultId: number;
  romVersionCode: number;
  score: number;
}
