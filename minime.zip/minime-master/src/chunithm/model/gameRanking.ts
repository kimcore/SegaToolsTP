export interface GameRankingItem {
  id: bigint;
  point: bigint;
}
