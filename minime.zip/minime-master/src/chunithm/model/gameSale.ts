export interface GameSaleItem {
  orderId: number;
  type: number;
  id: number;
  rate: number;
  startDate: Date;
  endDate: Date;
}
