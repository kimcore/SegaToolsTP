export interface UserActivityItem {
  kind: number;
  activityId: number; // This is just called "id" in the JSON!
  sortNumber: number;
  param1: number;
  param2: number;
  param3: number;
  param4: number;
}
