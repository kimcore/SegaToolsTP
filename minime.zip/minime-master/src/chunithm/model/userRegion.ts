export interface UserRegionItem {
  regionId: number;
  playCount: number;
  created: Date;
}
