export interface UserItemItem {
  itemKind: number;
  itemId: number;
  stock: number;
  isValid: boolean;
}
