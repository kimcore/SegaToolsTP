create table "meta" ("schemaver" integer not null);
